CREATE TRIGGER update_tsc_update_time
AFTER UPDATE ON teacher_student_course
BEGIN
    UPDATE teacher_student_course
    SET update_time = CURRENT_TIMESTAMP
    WHERE id = NEW.id;
END;

