CREATE TRIGGER update_class_update_time
AFTER UPDATE ON class
BEGIN
    UPDATE class
    SET update_time = CURRENT_TIMESTAMP
    WHERE id = NEW.id;
END;

