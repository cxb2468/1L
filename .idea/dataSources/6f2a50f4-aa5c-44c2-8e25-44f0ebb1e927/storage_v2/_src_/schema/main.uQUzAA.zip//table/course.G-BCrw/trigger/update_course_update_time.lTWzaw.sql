CREATE TRIGGER update_course_update_time
AFTER UPDATE ON course
BEGIN
    UPDATE course
    SET update_time = CURRENT_TIMESTAMP
    WHERE id = NEW.id;
END;

