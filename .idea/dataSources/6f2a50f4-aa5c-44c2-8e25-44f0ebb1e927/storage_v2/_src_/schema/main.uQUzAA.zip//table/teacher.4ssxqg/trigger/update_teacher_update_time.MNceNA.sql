CREATE TRIGGER update_teacher_update_time
AFTER UPDATE ON teacher
BEGIN
    UPDATE teacher
    SET update_time = CURRENT_TIMESTAMP
    WHERE id = NEW.id;
END;

