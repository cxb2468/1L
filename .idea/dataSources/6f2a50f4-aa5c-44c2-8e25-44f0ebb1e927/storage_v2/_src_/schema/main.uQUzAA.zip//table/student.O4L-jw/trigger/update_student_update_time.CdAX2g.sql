CREATE TRIGGER update_student_update_time
AFTER UPDATE ON student
BEGIN
    UPDATE student
    SET update_time = CURRENT_TIMESTAMP
    WHERE id = NEW.id;
END;

