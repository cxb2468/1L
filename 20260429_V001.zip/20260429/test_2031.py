# 测试2031年农历十二月生日转换
from birthday_converter import convert_lunar_to_target_year_solar

print("="*60)
print("测试2031年农历十二月生日转换")
print("="*60)

test_cases = [
    ("十二月初五", 2031),
    ("十二月初三", 2031),
    ("腊月二十五", 2025),  # 之前测试过的案例
    ("八月初五", 2026),    # 普通月份
]

for lunar_str, year in test_cases:
    result = convert_lunar_to_target_year_solar(lunar_str, year)
    if result:
        print(f"✓ 农历{lunar_str} ({year}年) → 公历 {result.strftime('%Y-%m-%d')}")
    else:
        print(f"✗ 农历{lunar_str} ({year}年) → 未设置")

print("="*60)
