# 详细测试2031年农历十二月
from lunarcalendar import Lunar

print("="*80)
print("详细测试2031年农历十二月初五和初三的转换")
print("="*80)

test_cases = [
    (2030, 12, 5, False),
    (2031, 12, 5, False),
    (2032, 12, 5, False),
    (2030, 12, 3, False),
    (2031, 12, 3, False),
    (2032, 12, 3, False),
]

for lunar_year, month, day, is_leap in test_cases:
    try:
        lunar = Lunar(lunar_year, month, day, isleap=is_leap)
        solar_date = lunar.to_date()
        marker = "✓ 在2031年内" if solar_date.year == 2031 else ""
        print(f"农历{lunar_year}年{month}月初{day} → 公历 {solar_date.strftime('%Y-%m-%d')} ({solar_date.year}年) {marker}")
    except Exception as e:
        print(f"农历{lunar_year}年{month}月初{day} → 错误: {e}")

print("="*80)
print("\n结论：如果以上没有任何一个在2031年内，说明这两个农历日期在2031年没有对应的公历生日")
