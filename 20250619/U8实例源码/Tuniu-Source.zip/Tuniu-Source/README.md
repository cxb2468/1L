# Tuniu-Source

《[仿途牛旅行](http://community.apicloud.com/bbs/forum.php?mod=viewthread&tid=444&extra=page%3D1)》

作者：北京的雪

描述：个人觉得这个项目作者在处理侧滑跳转切换的方法特别好，为了在页面切换后同时拥有侧滑，通过groupFrame配合实现了。所以灵活使用各种方法能够做出很多不一样的APP。
