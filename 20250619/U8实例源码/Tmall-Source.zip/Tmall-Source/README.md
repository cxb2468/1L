# imitate-tmall

《[仿天猫商城](http://community.apicloud.com/bbs/forum.php?mod=viewthread&tid=673&extra=page%3D1)》

作者：lalalalalala

描述：可参考主页配合 frameGroup 来进行导航切换。除布局外很多切换效果实际都可以使用这种方式，比如：幻灯片、Table 布局切换等。
