# 163news-Source

《[仿网易新闻](http://community.apicloud.com/bbs/forum.php?mod=viewthread&tid=1214&extra=page%3D1)》

作者：register

描述：该分享用到了云数据，不过对于新人，还是期待作者提供上数据结构等。
