#前言

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;本课程是以开发一个实际APP项目为主线，按照APP开发的标准流程一步步来讲解如何从0开始开发一款APP。从需求梳理开始，包括：需求分析、架构设计、界面布局、功能分解、服务对接、接口联调、编码规范、性能优化、发布更新等等。希望大家可以通过整个课程了解一个标准APP全生命周期的开发流程。

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;在APP的实际开发过程中会穿插介绍APICloud的相关技术点，包括平台的使用、APICloud应用设计思想、云控制台操作、各类扩展API的调用以及一些开发技巧和注意事项。

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;希望通过课程和大家一起交流，共同分享，不断的来完善教程、实例代码和案例。谢谢。