# 用于演示 APICloud 应用转换 微信公众号的示例源码.

## 目录说明

* ./widget 标准 APICloud Widget 包.
* ./A6055337516013 在 APICloud 云编译后生成的微信公众号源码包

## 入门文档

* [如何快速将 APICloud 应用转换为微信公众号?
](http://docs.apicloud.com/Wechatoffacc/apicloud_web_adapter_guid)
