# eleme

《[饿了么](http://community.apicloud.com/bbs/forum.php?mod=viewthread&tid=638&extra=page%3D1)》

作者：ringking

描述：该项目是一个比较常见以侧滑作为导航的APP，项目主要以布局为主，并结合平台的方法及个别三方自定义模块( baiduLocation )的纯静态APP。因为没有涉及到太多的逻辑，但在布局上使用了很多出色布局方式和利用css3来做到高效的布局，所以可以拿来作为布局上的参考，html文件可以直接通过浏览器的来查看效果。
