# Fanli-Source

《[仿返利网](http://community.apicloud.com/bbs/forum.php?mod=viewthread&tid=832&extra=page%3D1)》

作者：lalalalalala

描述：这个项目值得参考有首页的flex布局，如果将这个完全这套布局方式掌握了，以后再项目中很多复杂的布局都可以轻而易举的做出来。然后可以参考参考怎样在远程网页中注入自己的代码，并去执行，这个项目只是简单的运用，借鉴以后可以去做一些更深层的逻辑。
