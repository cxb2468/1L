# Qiushibaike-Source

《[仿糗事百科](http://community.apicloud.com/bbs/forum.php?mod=viewthread&tid=1036&extra=page%3D1)》

作者：lalalalalala

描述：这个应用值得参考的是，主题切换、右侧弹出层，还有一个我觉得特别应该值得参考的是，从应用的内容来看这些html是被单独分离在了各个相应的文件夹中，当然了其他项目这样做的也有，个人觉得这样方便后期维护和查找。
