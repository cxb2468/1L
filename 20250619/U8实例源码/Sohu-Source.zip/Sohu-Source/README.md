# Sohu-Source

《[仿搜狐视频](http://community.apicloud.com/bbs/forum.php?mod=viewthread&tid=405&extra=page%3D1)》

作者：ringking

描述：该项目是以展示为主的静态 APP，可以查看源码看看作者怎么样去做应用的布局排版。
