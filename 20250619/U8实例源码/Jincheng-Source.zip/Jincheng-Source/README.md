# Jincheng-Source

《[仿玩转晋城](http://community.apicloud.com/bbs/forum.php?mod=viewthread&tid=291&extra=page%3D1)》

作者：APICloud

描述：该分享提供了详细的使用文档，并分享云数据表结构源文件。项目中使用涉及到 doT.js 使用、数据云增删改查使用等一系列模块用法，是一个端到云完整的应用。
